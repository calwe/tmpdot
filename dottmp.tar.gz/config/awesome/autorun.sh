#!/usr/bin/env bash

run() {
    if ! pgrep -f "$1" ;
    then
        "$@"&
    fi
}

run "nm-applet"
run "lxpolkit"
run "fcitx5"
run "pipewire"
run "pipewire-pulse"
run "wireplumber"
run "insyc start"
